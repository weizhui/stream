#!/bin/bash

# 定义要测试的数组大小范围
START_SIZE=100000
END_SIZE=1100000000
STEP=10000

# 循环测试不同数组大小
for ((size=$START_SIZE; size<=$END_SIZE; size +=$STEP)); do
    # 计算内存占用（每个元素8字节，3个数组）
    
    # 设置参数并
    make STREAM_ARRAY_SIZE=$size NTIMES=20
    
    # 检查编译是否成功
    if [ $? -ne 0 ]; then
        echo "编译失败，跳过本次测试"
        make clean
        continue
    fi
    echo "运行测试..."
    export OMP_NUM_THREADS=2      # 设置为实际物理核心数
    export OMP_PROC_BIND=true
    export OMP_PLACES=cores
    numactl --cpunodebind=0 ./stream_c.exe
    
    # 清理
    make clean
    
    # 暂停1秒
    sleep 1
done

echo "所有测试完成!"