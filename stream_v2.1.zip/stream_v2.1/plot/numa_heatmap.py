import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# 设置中文显示和整体风格
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'Microsoft YaHei', 'DejaVu Sans']  # 解决中文显示
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示
sns.set_style("whitegrid", {'axes.grid': False})

# 读取CSV文件
df = pd.read_csv('bandwidth.csv')  # 替换为你的文件名

# 创建节点列表
numa_nodes = sorted(set(df['numa1'].unique()) | set(df['numa2'].unique()))

# 创建带宽矩阵
matrix = pd.DataFrame(np.zeros((len(numa_nodes), len(numa_nodes))),
                      index=numa_nodes, 
                      columns=numa_nodes)

# 填充矩阵值
for _, row in df.iterrows():
    matrix.at[row['numa1'], row['numa2']] = row['bandwidth(GB/s)']

# 创建热力图
plt.figure(figsize=(12, 8))
ax = sns.heatmap(
    matrix,
    annot=True,                # 显示数值
    fmt=".2f",                # 数值格式 (保留1位小数)
    cmap="Blues",             # 使用蓝色调色板
    linewidths=0.5,            # 单元格间线宽
    linecolor='white',         # 单元格间线颜色
    cbar_kws={'label': '(GB/s)'}  # 颜色条标签
)

# 设置标题和标签
# plt.title('NUMA节点间访问带宽', fontsize=15, pad=20)
plt.xlabel('NUMA B', fontsize=12)
plt.ylabel('NUMA A', fontsize=12)

# 调整布局
plt.tight_layout()

# 保存图像 (可选)
plt.savefig('numa_heatmap.png', dpi=600)

# 显示图像
plt.show()