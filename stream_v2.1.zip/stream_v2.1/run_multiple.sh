#!/bin/bash

# 定义要测试的数组大小范围
# START_SIZE=10000        # 0.1    MB -> 0.1*1024*1024/BYTES_PER_ELEM
# END_SIZE=50000000       # 10^2.5 MB -> 316.2277*1024*1024/BYTES_PER_ELEM
START_SIZE=1020
END_SIZE=2000000 # or 8000000
# STEP=10000

# 输出目录
OUTDIR="output_csv"
mkdir -p "$OUTDIR"

# 先为每个 src 文件补表头（若已存在则跳过）
# for src in 0 1 2 3; do
for src in 1 2 3; do
  csv="$OUTDIR/node${src}.csv"
  if [ ! -f "$csv" ]; then
    echo "data_size,bandwidth,target_node" > "$csv"
  fi
done

# 外层两层：src/dst 都用 for
# for src in 0 1 2 3; do
for src in 1 2 3; do
  CSV="$OUTDIR/node${src}.csv"
  for dst in 0 1 2 3; do
    # 循环测试不同数组大小（保持你的原结构）
    for ((size=$START_SIZE; size<=$END_SIZE; size = size * 101 / 100)); do
        # 清理
        make clean

        # 设置参数并编译：把 4 个宏都传进去
        make STREAM_ARRAY_SIZE=$size NTIMES=20 TARGET_NODE=$dst OUTPUT_DIR="$CSV"

        # 检查编译是否成功
        if [ $? -ne 0 ]; then
            echo "编译失败 (size=$size src=$src dst=$dst)，跳过本次测试"
            make clean
            continue
        fi

        echo "运行测试... size=$size src=$src dst=$dst -> $CSV"
        export OMP_NUM_THREADS=2
        export OMP_PROC_BIND=true
        export OMP_PLACES=cores

        # 绑定到 src
        numactl --cpunodebind=$src ./stream_c.exe

        # 暂停
        sleep 0.2
    done
  done
done

echo "所有测试完成!"
