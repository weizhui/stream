#define _GNU_SOURCE  // 必须在包含头文件前定义
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <numa.h>
#include <omp.h>
#include <sched.h>

#include <sys/syscall.h>  // 用于系统调用替代方案

#include <sched.h>
#ifndef STREAM_TYPE
#define STREAM_TYPE double
#endif

#ifndef NTIMES
#define NTIMES 20
#endif

#ifndef STREAM_ARRAY_SIZE
#define STREAM_ARRAY_SIZE 100000000
#endif

#ifndef OFFSET
#define OFFSET 0
#endif

#define HLINE "-------------------------------------------------------------\n"

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

// 每个线程的数据结构
typedef struct {
    size_t array_size;
    STREAM_TYPE *a;
    STREAM_TYPE *b;
    STREAM_TYPE *c;
    double min_time[4];
    double max_time[4];
    double avg_time[4];
    double bandwidth[4];
} ThreadData;

static const char *label[4] = {"Copy:      ", "Scale:     ", "Add:       ", "Triad:     "};

static const double bytes_per_op[4] = {
    2 * sizeof(STREAM_TYPE),
    2 * sizeof(STREAM_TYPE),
    3 * sizeof(STREAM_TYPE),
    3 * sizeof(STREAM_TYPE)
};

// double mysecond()
// {
//     struct timespec ts;
//     clock_gettime(CLOCK_MONOTONIC, &ts);
//     return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
// }
#include <sys/time.h>

double mysecond()
{
        struct timeval tp;
        struct timezone tzp;
        int i;

        i = gettimeofday(&tp,&tzp);
        return ( (double) tp.tv_sec + (double) tp.tv_usec * 1.e-6 );
}



int checktick()
{
    int i, minDelta, Delta;
    double t1, t2, timesfound[20];
    for (i = 0; i < 20; i++) {
        t1 = mysecond();
        while ((t2 = mysecond()) == t1)
            ;
        timesfound[i] = t1 = t2;
    }
    minDelta = 1000000;
    for (i = 1; i < 20; i++) {
        Delta = (int)(1e6 * (timesfound[i] - timesfound[i - 1]));
        minDelta = MIN(minDelta, MAX(Delta, 0));
    }
    return minDelta;
}

// 验证结果函数（针对特定线程）
void checkSTREAMresultsForThread(ThreadData *thread)
{
    STREAM_TYPE aj, bj, cj;
    STREAM_TYPE aSumErr, bSumErr, cSumErr;
    STREAM_TYPE aAvgErr, bAvgErr, cAvgErr;
    double epsilon;
    size_t j;
    int err = 0;
    
    aj = 1.0;
    bj = 2.0;
    cj = 0.0;
    for (j = 0; j < thread->array_size; j++) {
        aj = 2.0E0 * aj;
        bj = 2.0E0 * bj;
        cj = aj + bj;
    }
    aj = aj * (thread->array_size - 1);
    bj = bj * (thread->array_size - 1);
    cj = cj * (thread->array_size - 1);

    aSumErr = 0.0;
    bSumErr = 0.0;
    cSumErr = 0.0;
    for (j = 0; j < thread->array_size; j++) {
        aSumErr += fabs(thread->a[j] - aj);
        bSumErr += fabs(thread->b[j] - bj);
        cSumErr += fabs(thread->c[j] - cj);
    }
    aAvgErr = aSumErr / thread->array_size;
    bAvgErr = bSumErr / thread->array_size;
    cAvgErr = cSumErr / thread->array_size;

    epsilon = 1.e-8;
    if (fabs(aAvgErr / aj) > epsilon) {
        err++;
        printf("Error in thread: a[%zu] avg error = %e\n", j, aAvgErr);
    }
    if (fabs(bAvgErr / bj) > epsilon) {
        err++;
        printf("Error in thread: b[%zu] avg error = %e\n", j, bAvgErr);
    }
    if (fabs(cAvgErr / cj) > epsilon) {
        err++;
        printf("Error in thread: c[%zu] avg error = %e\n", j, cAvgErr);
    }
    if (err == 0) {
        // printf("Solution Validates for this thread\n");
    }
}

int main()
{
    int quantum;
    int BytesPerWord = sizeof(STREAM_TYPE);
    int k;
    
    
    // NUMA初始化
    if (numa_available() < 0) {
        fprintf(stderr, "NUMA not available\n");
        return 1;
    }
    
    const int num_nodes = 1;
    const int threads_per_node = 8;
    const int total_threads = num_nodes * threads_per_node;
    
    printf("Total memory required  = %.1f MiB\n",
        (3 * total_threads * BytesPerWord * (double)STREAM_ARRAY_SIZE) / (1024.0 * 1024.0));

    printf(HLINE);
    printf("STREAM Local NUMA Bandwidth Test\n");
    printf("System has %d NUMA nodes\n", num_nodes);
    printf("Total threads: %d\n", total_threads);
    printf(HLINE);
    
    quantum = checktick();
    printf("Clock granularity: %d microseconds\n", quantum);
    printf(HLINE);
    
    // 主测试循环
    STREAM_TYPE scalar = 3.0;
    
    // 为每个线程创建数据结构
    ThreadData *thread_data = (ThreadData *)malloc(total_threads * sizeof(ThreadData));
    if (!thread_data) {
        fprintf(stderr, "Memory allocation failed for thread data\n");
        return 1;
    }

    printf("Array size = %llu (elements), Offset = %d (elements)\n" , (unsigned long long) STREAM_ARRAY_SIZE, OFFSET);
    printf("Each kernel will be executed %d times.\n", NTIMES);

    double total_bandwidth = 0.0;
    
    for (k = 0; k < NTIMES; k++) {

        // 绑定线程到当前节点
        #pragma omp parallel num_threads(total_threads) proc_bind(close)
        {
            int tid = omp_get_thread_num();
            int cpu=-1;


            // 方法1: 使用sched_getcpu()
            #ifdef __linux__
            cpu = sched_getcpu();
            #endif
            
            // 方法2: 替代方案 - 直接系统调用
            if (cpu < 0) {
                #ifdef SYS_getcpu
                cpu = syscall(SYS_getcpu, NULL, NULL, NULL);
                #endif
            }
            
            
            int node_id = cpu / threads_per_node +  0;  // 计算NUMA节点ID

            // 第一次迭代时初始化内存
            if (k == 0) {
                thread_data[tid].array_size = STREAM_ARRAY_SIZE;
                
                // 在本地节点上分配内存
                thread_data[tid].a = (STREAM_TYPE *)numa_alloc_onnode(
                    STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE), node_id);
                thread_data[tid].b = (STREAM_TYPE *)numa_alloc_onnode(
                    STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE), node_id);
                thread_data[tid].c = (STREAM_TYPE *)numa_alloc_onnode(
                    STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE), node_id);

                
                if (!thread_data[tid].a || !thread_data[tid].b || !thread_data[tid].c) {
                    fprintf(stderr, "Memory allocation failed for thread %d\n", tid);
                    exit(1);
                }
                
                // 初始化数组
                for (size_t j = 0; j < STREAM_ARRAY_SIZE; j++) {
                    thread_data[tid].a[j] = 1.0;
                    thread_data[tid].b[j] = 2.0;
                    thread_data[tid].c[j] = 0.0;
                }
                
                // 初始化时间统计
                for (int j = 0; j < 4; j++) {
                    thread_data[tid].min_time[j] = FLT_MAX;
                    thread_data[tid].max_time[j] = 0.0;
                    thread_data[tid].avg_time[j] = 0.0;
                    thread_data[tid].bandwidth[j] = 0.0;
                }
            }

            double start;
            STREAM_TYPE *a = thread_data[tid].a;
            STREAM_TYPE *b = thread_data[tid].b;
            STREAM_TYPE *c = thread_data[tid].c;
            

            // Copy
            start = mysecond();
            for (size_t j = 0; j < STREAM_ARRAY_SIZE; j++) {
                c[j] = a[j];
            }
            double copy_time = mysecond() - start;
            
            // Scale
            start = mysecond();
            for (size_t j = 0; j < STREAM_ARRAY_SIZE; j++) {
                b[j] = scalar * c[j];
            }
            double scale_time = mysecond() - start;
            
            // Add
            start = mysecond();
            for (size_t j = 0; j < STREAM_ARRAY_SIZE; j++) {
                c[j] = a[j] + b[j];
            }
            double add_time = mysecond() - start;
            
            // Triad
            start = mysecond();
            for (size_t j = 0; j < STREAM_ARRAY_SIZE; j++) {
                a[j] = b[j] + scalar * c[j];
            }
            double triad_time = mysecond() - start;
            
            // 保存时间结果
            double times[4] = {copy_time, scale_time, add_time, triad_time};
            for (int j = 0; j < 4; j++) {
                if (k > 0) { // 跳过第一次迭代
                    thread_data[tid].avg_time[j] += times[j];
                    thread_data[tid].min_time[j] = MIN(thread_data[tid].min_time[j], times[j]);
                    thread_data[tid].max_time[j] = MAX(thread_data[tid].max_time[j], times[j]);
                }
            }
            
            // 最后一次迭代计算带宽
            if (k == NTIMES - 1) {
                for (int j = 0; j < 4; j++) {
                    thread_data[tid].avg_time[j] /= (NTIMES - 1);
                    thread_data[tid].bandwidth[j] = 
                        (bytes_per_op[j] * STREAM_ARRAY_SIZE) / 
                        (thread_data[tid].min_time[j] * 1e9);
                }
                
                // 原子操作更新总带宽
                #pragma omp atomic
                total_bandwidth += thread_data[tid].bandwidth[3]; // Triad带宽
            }
        }
    }
    
    printf(HLINE);
    printf("TOTAL BANDWIDTH (SUM OF ALL Triad OPERATIONS): %.1f GB/s\n", total_bandwidth);
    printf(HLINE);
    
    // 验证结果
    for (int tid = 0; tid < total_threads; tid++) {
        checkSTREAMresultsForThread(&thread_data[tid]);
    }
    printf(HLINE);
    
    // 释放内存
    for (int tid = 0; tid < total_threads; tid++) {
        numa_free(thread_data[tid].a, STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE));
        numa_free(thread_data[tid].b, STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE));
        numa_free(thread_data[tid].c, STREAM_ARRAY_SIZE * sizeof(STREAM_TYPE));
    }
    free(thread_data);
    
    return 0;
}