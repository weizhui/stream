import csv
import matplotlib.pyplot as plt
import sys
import numpy as np

def plot_bandwidth(csv_file, output_image=None):
    # 存储数据
    memory = []
    bandwidth = []
    
    # 读取CSV文件
    try:
        with open(csv_file, 'r') as file:
            reader = csv.reader(file)
            next(reader)  # 跳过标题行
            for row in reader:
                if len(row) >= 2:
                    try:
                        mem_val = float(row[0])
                        bw_val = float(row[1])
                        memory.append(mem_val)
                        bandwidth.append(bw_val)
                    except ValueError:
                        continue
    except FileNotFoundError:
        print(f"错误：文件 '{csv_file}' 未找到")
        return
    
    if not memory or not bandwidth:
        print("错误：没有有效数据可绘制")
        return
    
    # 创建图表
    plt.figure(figsize=(12, 8))
    
    # 设置指定的横坐标刻度
    # specified_ticks = [16,1024,2048,4096,8192,16384,32768,65536]
    # specified_ticks = [16,64,512,1024,2048,4096]
    # specified_ticks = [16,512,1024,2048,4096,5000,8192]
    # specified_ticks = [16,512,1024,2048,4096,8192,16384]
    specified_ticks = [16,512,1024,2048,4096,8192,16384,32768]
    
    # 解决精度问题：使用容差匹配
    tolerance = 0.1  # 允许0.1的误差
    # actual_ticks = []
    
    # # 为每个指定刻度找到最接近的实际数据点
    # for tick in specified_ticks:
    #     closest = None
    #     min_diff = float('inf')
        
    #     for m in memory:
    #         diff = abs(m - tick)
    #         if diff < min_diff:
    #             min_diff = diff
    #             closest = m
        
    #     # 如果找到足够接近的点，添加到实际刻度
    #     if min_diff <= tolerance:
    #         actual_ticks.append(closest)
    
    # 绘制折线图
    plt.plot(memory, bandwidth, marker='o', markersize=8, linewidth=3, 
             color='#1f77b4')
    
    # 设置图表标题和标签
    plt.title('Triad Bandwidth (GB/s)', fontsize=18, fontweight='bold', pad=20)
    plt.xlabel('Dataset size (MiB)', fontsize=14, labelpad=15)
    plt.ylabel('Bandwidth (GB/s)', fontsize=14, labelpad=15)
    
    # 设置横坐标刻度和标签
    # plt.xscale('log')
    # plt.tick_params(axis='x', which='minor', length=0) 
    plt.xticks(specified_ticks , [str(t) for t in specified_ticks ], 
               rotation=90, ha='right', fontsize=8)
    
    # 使用对数刻度使分布更均匀
    # plt.xscale('log')
    
    # 设置纵坐标范围
    max_bandwidth = max(bandwidth)
    min_bandwidth = min(bandwidth)
    plt.ylim(0, max_bandwidth * 1.2)  # 留20%顶部空间
    
    # 添加水平网格线（不添加垂直网格线）
    plt.grid(True, axis='y', linestyle='--', alpha=0.7)
    
    # 设置图表边框
    for spine in plt.gca().spines.values():
        spine.set_visible(False)
    
    # 添加底部边框
    plt.gca().spines['bottom'].set_visible(True)
    
    # 自动调整布局
    plt.tight_layout()
    
    # 保存或显示图表
    if output_image:
        plt.savefig(output_image, dpi=300, bbox_inches='tight')
        print(f"图表已保存为 '{output_image}'")
    else:
        plt.show()

if __name__ == "__main__":
    # 检查命令行参数
    if len(sys.argv) < 2:
        print("使用方法: python plot_bandwidth.py <输入CSV文件> [输出图片文件]")
        print("示例: python plot_bandwidth.py data.csv bandwidth_plot.png")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    output_image = sys.argv[2] if len(sys.argv) > 2 else None
    
    plot_bandwidth(csv_file, output_image)