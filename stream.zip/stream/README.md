# STREAM基准测试（NUMA绑定版）

本项目基于Jeff Hammond的STREAM项目修改，[https://github.com/jeffhammond/STREAM.git](https://github.com/jeffhammond/STREAM.git)修改的STREAM基准测试代码。修改后的代码，实现了NUMA感知的内存带宽测试工具,支持将线程绑定到特定CPU核心，并强制要求线程使用指定NUMA节点的内存，以进行性能测试。

## 项目概述

此代码通过将线程绑定到固定CPU核心并指定使用特定NUMA节点的内存，实现了对STREAM基准测试在不同NUMA配置下的精确性能评估。

## 使用说明

### 1. 检查NUMA配置
使用以下命令查看系统的NUMA节点数量、CPU核心分布以及内存分配情况：
```bash
numactl -H
```

### 2. 修改代码参数
根据所需的NUMA节点和CPU配置，调整以下参数以运行STREAM基准测试：

#### 2.1 修改`stream.c`
- **修改第165-166行**，指定NUMA节点数量和每个节点的CPU核心数：
  ```c
  const int num_nodes = 1;          // NUMA节点数量
  const int threads_per_node = 8;   // 每个节点的CPU核心数
  ```
- **修改第219行**，指定当前线程使用哪个NUMA节点的内存：
  ```c
  int node_id = cpu / threads_per_node + 0; 
  // 示例：若cpu=14且threads_per_node=8，则node_id=(14/8)+0=2
  ```
  在此示例中，CPU 14上的线程将使用第2个NUMA节点的内存。

#### 2.2 修改`test.sh`
- **修改第4-6行**，设置测试数组的数据范围。
- **修改第22行和第25行**：
  - **第22行**：指定线程总数，每个线程绑定到一个独立的CPU核心。
  - **第25行**：指定使用的NUMA节点ID。确保所选节点上的CPU核心总数与第22行指定的线程数一致。

### 3. 绘制结果图表
要生成测试结果的图表：
- `bash test.sh` 生成实验数据。
- 清理输出数据并将其转换为CSV格式。
- 使用`plot`目录中的绘图脚本进行数据可视化。

### 4. plot目录
- `numa_plot.py` 制作不同数据下峰值性能变化趋势。
- `numa_heatmap.py` 生成所有节点热力图。


## 注意事项
- 确保NUMA节点和CPU核心配置与系统硬件一致，以避免错误。
- `plot`目录中留存一版数据图以供参考,使用前准备好数据。
